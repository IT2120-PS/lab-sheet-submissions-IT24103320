setwd("C:\\Users\\IT24103320\\Downloads\\Lab 10-20251014")

observed <- c(55, 62, 43, 46, 50)
prob <- c(0.2, 0.2, 0.2, 0.2, 0.2)

chisq.test(x = observed, p = prob)


file_path <- "https://www.sthda.com/sthda/RDoc/data/housetasks.txt"

housetasks <- read.delim(file_path, row.names = 1)
housetasks


#Exercise
#1 customer choose each snack type(A,B,C,D) with equal probability
#PA=PB=PC=PD

#H1 = Customer do not choose each snack type with equal probability

observed <- c(120, 95, 85, 100)
total <- sum(observed)
expected <- rep(total / 4,4)

observed
expected
chisq.test <- chisq.test(observed, p = c(0.25, 0.25, 0.25, 0.25))

chisq.test


#since p value (0.08966) > 0.05
#fail t o reject H0
#no significant evidence that customer prefer one snack type over another