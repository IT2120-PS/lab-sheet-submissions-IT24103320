setwd("C:\\Users\\IT24103320\\Downloads\\IT24103320")

data<- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)

popmn<-mean(Weight.kg.)
print(popmn)

popvar<-var(Weight.kg.)
print(popvar)

popsd <- sqrt(popvar)
popsd

#create null vectors
samples<- c()
n<- c()
n

for(i in 1:25){
  s <- sample(Weight.kg., 6, replace = TRUE)
  samples<- cbind(samples,s)
  n<- c(n, paste('s', i))
}


s
n

colnames(samples) = n
n
colnames(samples)


s.means<- apply(samples,2, mean ) 
s.means


s.vars<- apply(samples,2,var) 

s.sd <- sqrt(s.vars)
s.sd

samplemean<- mean(s.means)
samplemean

samplevars <- var(s.means)

samplesd <- sqrt(samplevars)
samplesd

popmn
samplemean

truesd = popsd/6
truesd
samplesd




