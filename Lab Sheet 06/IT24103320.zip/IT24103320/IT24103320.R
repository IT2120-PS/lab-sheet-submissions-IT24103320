n <- 50
p <- 0.85

# =Binomial Distribution
#p(x>=47) = 1-p(x<=46)

1- pbinom(46, 50, 0.85, lower.tail = TRUE)


#x = number of calls recieved in an hour
#Poisson Distribution 

#lambda = 12

dpois(15 , 12)