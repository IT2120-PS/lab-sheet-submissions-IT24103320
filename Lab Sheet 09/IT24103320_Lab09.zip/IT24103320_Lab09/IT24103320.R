baking_times <- rnorm(25, mean=45, sd=2)

t.test(baking_times, mu=46, alternative="less")